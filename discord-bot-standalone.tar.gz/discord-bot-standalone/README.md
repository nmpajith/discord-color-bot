# Discord Color Bot

Cycles a Discord role's color every 1 second through a rainbow of colors.

## Deploy free on Railway

1. Create a free account at https://railway.app
2. Click **New Project** → **Deploy from GitHub repo**
   - Push this folder to a GitHub repo first, OR use **Deploy from template**
3. In Railway, go to your project → **Variables** and add:
   - `DISCORD_BOT_TOKEN` = your bot token
   - `DISCORD_GUILD_ID` = your server ID
   - `DISCORD_ROLE_ID` = the role ID to color-cycle
4. Railway will automatically run `npm start` and keep it alive 24/7

## Run locally

```bash
npm install
DISCORD_BOT_TOKEN=xxx DISCORD_GUILD_ID=xxx DISCORD_ROLE_ID=xxx node bot.js
```

## Discord bot permissions required

- **Manage Roles** permission
- Bot's role must be positioned **above** the target role in Server Settings → Roles
